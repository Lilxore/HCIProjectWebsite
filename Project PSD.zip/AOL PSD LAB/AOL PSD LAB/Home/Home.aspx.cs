﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Home
{
    public partial class Home : System.Web.UI.Page
    {

            Database1Entities dn = new Database1Entities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                        
                List<User> users = dn.Users.Where(x => x.Roleid == 3).ToList();
                GridViewCus.DataSource = users;
                GridViewCus.DataBind();
            }   
            GridViewCus.Visible = false;
                
            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }

            var currentUser = (User)Session["user_session"];

            if (currentUser.Roleid == 2)
            {
                using (var db = new Database1Entities())
                {
                    var usersWithRoleId3 = db.Users.Where(u => u.Roleid == 3).ToList();

                    GridViewCus.DataSource = usersWithRoleId3;
                    GridViewCus.DataBind();
                    GridViewCus.Visible = true;
                }
            }
        }
        protected void GridViewCus_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridViewRow row = GridViewCus.Rows[e.NewEditIndex];
            string Id = row.Cells[0].Text.ToString();
            Response.Redirect("EditCustomerData.aspx?ID="+Id);
        }

        protected void GridViewCus_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            GridViewRow row = GridViewCus.Rows[e.RowIndex];
            string Id = row.Cells[0].Text.ToString();

            int userId = Int32.Parse(Id);
            User user = (dn.Users.Find(userId));

            dn.Users.Remove(user);
            dn.SaveChanges();

            GridViewCus.DataSource = dn.Users.Where(x => x.Roleid == 3).ToList();
            GridViewCus.DataBind();

        }
    }
}