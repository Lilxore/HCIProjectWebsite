﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;
using AOL_PSD_LAB.Factory;
using AOL_PSD_LAB.Handler;
using AOL_PSD_LAB.Controller;

namespace AOL_PSD_LAB.Home
{

    public partial class AdmEditRamen : System.Web.UI.Page
    {
        Database1Entities db = new Database1Entities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }
            string Id = Request["ID"];

            if (IsPostBack == false)
            {
                List<string> Gen = db.Ramen.Select(x => x.Borth).Distinct().ToList();
                List<string> ging = db.Ramen.Select(x => x.Meatid.ToString()).Distinct().ToList();

                DropDownListNewMeat.DataSource = ging;
                DropDownListNewMeat.DataBind();

                DropDownListNewBorth.DataSource = Gen;
                DropDownListNewBorth.DataBind();


                int userId = Int32.Parse(Id);
                int.TryParse(Id, out userId);
                Raman r = (db.Ramen.Find(userId));
                NewRamen.Text = r.Name;
                NewPrice.Text = r.Price;
                DropDownListNewBorth.SelectedValue = r.Borth;
                DropDownListNewMeat.SelectedValue = r.Meatid.ToString();
            }
        }

        protected void BtnSubmit_Click1(object sender, EventArgs e)
        {
            String NewId = Request["ID"];
            String NRamen = NewRamen.Text;
            String NPrice = NewPrice.Text;
            String NMeatId = DropDownListNewMeat.Text;
            String NBroth = DropDownListNewBorth.Text;

            int NewMeatId = Int32.Parse(NMeatId);
            int userId = Int32.Parse(NewId);
            Raman r = (db.Ramen.Find(userId));

            Meat meat = db.Meats.FirstOrDefault(m => m.id == NewMeatId);

            r.Meat = meat;
            r.Name = NRamen;
            r.Price = NPrice;
            r.Borth = NBroth;

            db.SaveChanges();
            Response.Redirect("~/Home/AdmManageRamen.aspx");


        }
    }
}