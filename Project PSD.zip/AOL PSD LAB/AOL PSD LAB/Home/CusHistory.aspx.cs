﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Repository;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Home
{
    public partial class CusHistory : System.Web.UI.Page
    {
        public int currid { get; set; }
        public List<Header> transactions = new List<Header>();
        protected void Page_Load(object sender, EventArgs e)
        {
            transactions = TransactionRepository.GetHeaders();
            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }
            currid = ((User)Session["user_session"]).Id;
            


        }
    }
}