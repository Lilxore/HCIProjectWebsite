﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Home
{
    public partial class EditProfile : System.Web.UI.Page
    {
        Database1Entities db = new Database1Entities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }

            if(IsPostBack == false)
            {
                List<string> Gen = db.Users.Select(x => x.Gender).Distinct().ToList();
                DropDownListGender.DataSource = Gen;
                DropDownListGender.DataBind();
 
                string labelUsername = Request.QueryString["LabelUsername"];
                string labelEmail = Request.QueryString["LabelEmail"];
                string labelGender = Request.QueryString["LabelGender"];
                string labelPassword = Request.QueryString["LabelPassword"];

                TextBoxUname.Text = labelUsername;
                TextBoxEmail.Text = labelEmail;
                TextBoxPassword.Text = labelPassword;

                User u = (User)Session["user_session"];
                TextBoxUname.Text = u.Username;
                //TextBoxRoleId.Text = u.Roleid.ToString();
                TextBoxEmail.Text = u.Email;
                DropDownListGender.SelectedValue = u.Gender;
               TextBoxPassword.Text = u.Password;
            }
        }

        protected void ButtonUpdate_Click(object sender, EventArgs e)
        {
            String NUname = TextBoxUname.Text;
            String NEmail = TextBoxEmail.Text;
            String NGender = DropDownListGender.Text.ToString();
            String NPassword = TextBoxPassword.Text;

            User u = (User)Session["user_session"]; 
            u.Username = NUname;
            u.Email = NEmail;
            u.Gender = NGender;
            u.Password = NPassword;

            DataBind();
            db.SaveChanges();
            Response.Redirect("~/Home/ViewProfile.aspx");


        }
    }
}