﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AOL_PSD_LAB.Home
{
    public partial class MasterPageAdmin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void AdmLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("Login.aspx");

        }

        protected void AdmHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminHome.aspx");
        }

        protected void AdmManageRamen_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdmManageRamen.aspx");
        }

        protected void AdmOrdQ_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdmOrderQueue.aspx");
        }

        protected void AdmProf_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdmProfile.aspx");
        }
        protected void AdmHistory_Click(object sender, EventArgs e)
        {
            Response.Redirect("TransactionDetail.aspx");
        }
        protected void AdmReport_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminReport.aspx");
        }
    }
}