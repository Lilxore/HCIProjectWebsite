﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Home;
using AOL_PSD_LAB.Models;
namespace AOL_PSD_LAB.Home
{
    public partial class CustomerProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }
            LabelUsername.Text = ((User)Session["user_session"]).Username;
            LabelEmail.Text = ((User)Session["user_session"]).Email;
            LabelGender.Text = ((User)Session["user_session"]).Gender;
            LabelPassword.Text = ((User)Session["user_session"]).Password;


        }

        protected void ButtonEdit_Click(object sender, EventArgs e)
        {
            string Username = LabelUsername.Text;
            string Email = LabelEmail.Text;
            string Gender = LabelGender.Text;
            string Password = LabelPassword.Text;
            Response.Redirect("~/Home/CusEditProfile.aspx?&LabelUsername=" + Username +
                "&LabelEmail=" + Email + "&LabelGender=" + Gender +
                "&LabelPassword=" + Password);
        }
    }
}