﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AOL_PSD_LAB.Home
{
    public partial class Cart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }
        protected void buyCartBtn_Click(object sender, EventArgs e)
        {
            // Handle the buy cart functionality
        }

        protected void clearCartBtn_Click(object sender, EventArgs e)
        {
            // Handle the clear cart functionality
        }
    }
}