﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Home
{
    public partial class OrderRamen : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindRamenGridView();
               
            }
        }

        private void BindRamenGridView()
        {
            using (Database1Entities db = new Database1Entities()) 
            {
                List<Raman> ramens = db.Ramen.ToList();
                GridViewCus.DataSource = ramens;
                GridViewCus.DataBind();
            }
        }

        
        protected void AddToQueueButton_Click(object sender, GridViewEditEventArgs e)
        {
            GridViewRow row = GridViewCus.Rows[e.NewEditIndex];
            string Id = row.Cells[0].Text.ToString();
            Response.Redirect("Cart.aspx?ID=" + Id);

        }

        
    }
}