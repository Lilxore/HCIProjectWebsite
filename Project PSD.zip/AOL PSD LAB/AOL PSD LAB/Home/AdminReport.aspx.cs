﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Dataset;
using AOL_PSD_LAB.Report;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;

namespace AOL_PSD_LAB.Home
{
    public partial class AdminReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Database1Entities db = new Database1Entities();
            CrystalReport1 report = new CrystalReport1();
            DataSet1 data = GetData(db.Headers.ToList());
            CrystalReportViewer1.ReportSource = report;
            report.SetDataSource(data);
            
        }

        public DataSet1 GetData(List<Header> tr)
        {
            DataSet1 data = new DataSet1();
            var header = data.headers;
            var detail = data.detail;

            foreach(var th in tr)
            {
                var headerRow = header.NewRow();
                headerRow["id"] = th.id;
                headerRow["CustomerId"] = th.CustomerId;
                headerRow["Staffid"] = th.Staffid;
                headerRow["Date"] = th.Date;
                header.Rows.Add(headerRow);

                foreach(var td in th.Details)
                {
                    var detailRow = detail.NewRow();
                    detailRow["Headerid"] = td.Headerid;
                    detailRow["Ramenid"] = td.Ramenid;
                    detailRow["Quantity"] = td.Quantity;
                    detail.Rows.Add(detailRow);
                }
            }

            return data;
        }



    }
}