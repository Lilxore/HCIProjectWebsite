﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Factory;

namespace AOL_PSD_LAB.Home
{
    public partial class InsertRamen : System.Web.UI.Page
    {
        Database1Entities db = new Database1Entities();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }

            if (IsPostBack == false)
            {
                //List<string> IdRamen = (from type in db.Meats select type.id.ToString()).ToList();
                List<string> IdRamen = db.Meats.Select(x => x.id.ToString()).Distinct().ToList();
                DropDownListMeatId.DataSource = IdRamen;
                DropDownListMeatId.DataBind();

            }
           

        }


        protected int OtomatisId()
        {
            int Idlama = db.Ramen.Max(x => x.id);
            int OtoId = Idlama + 1;
            return OtoId;
        }


        protected void ButtonSubmit_Click(object sender, EventArgs e)
        {

            Raman r = Factory.InsertRamen.create(OtomatisId(), (from tipe in db.Meats
                                                                where tipe.id.ToString() == DropDownListMeatId.Text.ToString()
                                                                select tipe.id).ToList().LastOrDefault(), 
                                                                TextBoxName.Text.ToString(), 
                                                                TextBoxBroth.Text.ToString(), 
                                                                TextBoxPrice.Text.ToString());                  
            db.Ramen.Add(r);
            db.SaveChanges();
            Response.Redirect("~/Home/ManageRamen.aspx");
        }
    }
}