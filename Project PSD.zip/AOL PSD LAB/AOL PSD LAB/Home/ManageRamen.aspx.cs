﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;
using AOL_PSD_LAB.Handler;
using AOL_PSD_LAB.Factory;
using AOL_PSD_LAB.Controller;

namespace AOL_PSD_LAB.Home
{
    public partial class ManageRamen : System.Web.UI.Page
    {
        static Database1Entities db = DatabaseSingleton.GetInstance();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }


            if (IsPostBack == false)
            {

                //List<Raman> ramen = RamenController.GetAllRamen();

                GridViewRamen.DataSource = db.Ramen.ToList();
                GridViewRamen.DataBind();
            }

        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home/InsertRamen.aspx");
        }

        protected void GridViewRamen_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridViewRow row = GridViewRamen.Rows[e.NewEditIndex];
            string Id = row.Cells[0].Text.ToString();
            Response.Redirect("EditRamen.aspx?ID=" + Id);
        }

        protected void GridViewRamen_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int Id =Int32.Parse(GridViewRamen.Rows[e.RowIndex].Cells[0].Text.ToString());
            EditRamenController.DeleteRamen(Id);
            List<Raman> ramen = EditRamenController.GetAllRamen();
            GridViewRamen.DataSource = ramen;
            GridViewRamen.DataBind();
        }
    }
}