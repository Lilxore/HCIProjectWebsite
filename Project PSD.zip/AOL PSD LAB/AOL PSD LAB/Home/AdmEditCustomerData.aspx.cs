﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;
using AOL_PSD_LAB.Controller;
using AOL_PSD_LAB.Factory;
using AOL_PSD_LAB.Handler;

namespace AOL_PSD_LAB.Home
{
    public partial class AdmEditCustomerData : System.Web.UI.Page
    {
        //EditCustomerController CustomerController = new EditCustomerController(new EditCustomerHandler
        //    (new EditCustomerRepository(new Database1Entities()), new EditCustomerFactory()));
        //Database1Entities db = new Database1Entities();

        static Database1Entities db = DatabaseSingleton.GetInstance();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }

            string Id = Request["ID"];
            if (IsPostBack == false)
            {
                List<string> Gen = EditCustomerController.GetDistinctGenders();
                DropDownList1.DataSource = Gen;
                DropDownList1.DataBind();

                int userId = Int32.Parse(Id);
                User p = EditCustomerController.GetUserById(userId);
                UnameNew.Text = p.Username;
                EmailNew.Text = p.Email;
                DropDownList1.SelectedValue = p.Gender;
            }
        }

        protected void BtnSubmit_Click1(object sender, EventArgs e)
        {
            String NewId = Request["ID"];
            String Username = UnameNew.Text;
            String Email = EmailNew.Text;
            String Gender = DropDownList1.Text.ToString();

            int userId = Int32.Parse(NewId);
            EditCustomerController.UpdateCustomer(userId, Username, Email, Gender);

            db.SaveChanges();
            DataBind();
            Response.Redirect("~/Home/AdminHome.aspx");
        }


    }
}