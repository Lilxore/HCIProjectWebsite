﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Handler;

namespace AOL_PSD_LAB.Home
{
    public partial class Login : System.Web.UI.Page
    {
        private LoginHandler handler;

        public Login()
        {
            handler = new LoginHandler();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["user_cookie"];
            if (cookie != null)
            {
                txtUsername.Text = cookie.Values["Username"];
                txtPassword.Text = cookie.Values["Password"];
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            User user = handler.ValidateUser(username, password);

            if (user == null)
            {
                lblError.Text = "User not found!";
                lblError.ForeColor = System.Drawing.Color.Red;
            }
            else if (user.Roleid == 2)
            {
                bool remember = Remember.Checked;

                if (remember)
                {
                    HttpCookie cookie = new HttpCookie("user_cookie");
                    cookie.Values["Username"] = username;
                    cookie.Values["Password"] = password;
                    cookie.Expires = DateTime.Now.AddMinutes(1);
                    Response.Cookies.Add(cookie);
                }

                Session["user_session"] = user;
                Response.Redirect("~/Home/Home.aspx");
            }
            else if (user.Roleid == 3)
            {
                bool remember = Remember.Checked;

                if (remember)
                {
                    HttpCookie cookie = new HttpCookie("user_cookie");
                    cookie.Values["Username"] = username;
                    cookie.Values["Password"] = password;
                    cookie.Expires = DateTime.Now.AddMinutes(1);
                    Response.Cookies.Add(cookie);
                }

                Session["user_session"] = user;
                Response.Redirect("~/Home/OrderRamen.aspx");
            }
            else if (user.Roleid == 1)
            {
                bool remember = Remember.Checked;

                if (remember)
                {
                    HttpCookie cookie = new HttpCookie("user_cookie");
                    cookie.Values["Username"] = username;
                    cookie.Values["Password"] = password;
                    cookie.Expires = DateTime.Now.AddMinutes(1);
                    Response.Cookies.Add(cookie);
                }

                Session["user_session"] = user;
                Response.Redirect("~/Home/AdminHome.aspx");
            }
        }
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home/Register.aspx");
        }


        }
}