﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;

namespace AOL_PSD_LAB.Home
{
    public partial class CusTransactionsDetails : System.Web.UI.Page
    {
        public Header head;
        protected void Page_Load(object sender, EventArgs e)
        {
            string id1 = Request.QueryString["id"];
            int id = int.Parse(id1);
            head = TransactionRepository.GetTransactionById(id);

            if (head == null)
            {
                Response.Redirect("TransactionDeatil.aspx");
            }
        }
    }
}