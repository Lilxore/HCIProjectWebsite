﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;
using AOL_PSD_LAB.Factory;
using AOL_PSD_LAB.Handler;
using AOL_PSD_LAB.Controller;

namespace AOL_PSD_LAB.Home
{

    public partial class EditRamen : System.Web.UI.Page
    {      
        static Database1Entities db = DatabaseSingleton.GetInstance();
        protected void Page_Load(object sender, EventArgs e)
        {          

            if (Session["user_session"] == null)
            {
                Response.Redirect("~/Home/Login.aspx");
            }
            

            if (IsPostBack == false)
            {
                string Id = Request["ID"];

                List<string> Gen = EditRamenController.GetDistinctBroth();
                List<string> ging = EditRamenController.GetDistinctMeatIds();

                DropDownListNewMeat.DataSource = ging;
                DropDownListNewMeat.DataBind();

                DropDownListNewBorth.DataSource = Gen;
                DropDownListNewBorth.DataBind();

                int userId = Int32.Parse(Id);
                Raman r = EditRamenController.FindramenById(userId);
                NewRamen.Text = r.Name;
                NewPrice.Text = r.Price;
                DropDownListNewBorth.SelectedValue = r.Borth;
                DropDownListNewMeat.SelectedValue = r.Meatid.ToString();
            }
        }

        protected void BtnSubmit_Click1(object sender, EventArgs e)
        {
            string Id = Request["ID"];
            int UpdateId = int.Parse(Id);
            Raman r = db.Ramen.Find(UpdateId);
            r.Name = NewRamen.Text;
            r.Meatid = int.Parse(DropDownListNewMeat.SelectedValue);
            r.Borth = DropDownListNewBorth.SelectedValue;
            r.Price = NewPrice.Text;
            //String NewId = Request["ID"];
            //String NRamen = NewRamen.Text;
            //String NPrice = NewPrice.Text;
            //String NMeatId = DropDownListNewMeat.SelectedValue;
            //String NBroth = DropDownListNewBorth.SelectedValue;

            //int NewMeatId = Int32.Parse(NMeatId);
            //int userId = Int32.Parse(NewId);

            //EditRamenController.UpdateRamen(userId, NewMeatId, NRamen, NBroth, NPrice);

            db.SaveChanges();
        
            Response.Redirect("~/Home/ManageRamen.aspx");
        }

        //public static int GetIdByName(string MeatName)
        //{
        //    Meat m = db.Meats.FirstOrDefault(p => p.name == MeatName);

        //    return m.id;
        //}
    }
}