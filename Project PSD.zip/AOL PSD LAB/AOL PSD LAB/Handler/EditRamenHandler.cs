﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;
using AOL_PSD_LAB.Factory;

namespace AOL_PSD_LAB.Handler
{
    public class EditRamenHandler
    {
 
        public static void UpdateRamen(int id, int meatId, string name, string broth, string price)
        {
            Raman ramen = EditRamenRepository.FindramenById(id);
            Meat kode = EditRamenRepository.GetMeatById(meatId);

            if (ramen != null)
            {
                kode.id= meatId;
                ramen.Name = name;
                ramen.Borth = broth;
                ramen.Price = price;
                EditRamenRepository.UpdateRamen(ramen);
            }
        }
        public static Raman FindramenById(int id)
        {
            return EditRamenRepository.FindramenById(id);
        }


        public static List<Raman> GetAllRamen()
        {
            return EditRamenRepository.GetAll();
        }

        public static List<string> GetDistinctBroth()
        {
            return EditRamenRepository.GetDistinctBroth();
        }

        public static List<string> GetDistinctMeatIds()
        {
            return EditRamenRepository.GetDistinctMeatIds();
        }

        public static void DeleteRamen(int id)
        {
            EditRamenRepository.DeleteRamen(id);
        }

    }
}