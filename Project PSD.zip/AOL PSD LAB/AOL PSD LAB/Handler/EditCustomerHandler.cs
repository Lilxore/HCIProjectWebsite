﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;
using AOL_PSD_LAB.Factory;

namespace AOL_PSD_LAB.Handler
{
    public class EditCustomerHandler
    {
        public static void UpdateCustomer(int id, string username, string email, string gender)
        {
            User user = EditCustomerRepository.FindCustomerById(id);
            if (user != null)
            {
                user.Username = username;
                user.Email = email;
                user.Gender = gender;
                EditCustomerRepository.UpdateCustomer(user);
            }
        }

        public static List<string> GetDistinctGenders()
        {
            return EditCustomerRepository.GetDistinctGenders();
        }

        public static User FindCustomerById(int id)
        {
            return EditCustomerRepository.FindCustomerById(id);
        }

    }
}