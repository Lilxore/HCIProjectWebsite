﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;
using AOL_PSD_LAB.Repository;

namespace AOL_PSD_LAB.Handler
{
    public class LoginHandler
    {
        private LoginRepository repository;

        public LoginHandler()
        {
            repository = new LoginRepository();
        }

        public User ValidateUser(string username, string password)
        {
            return repository.GetUserByUsernameAndPassword(username, password);
        }
    }
}