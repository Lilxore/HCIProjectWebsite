﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Handler;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Controller
{
    public class EditCustomerController
    {

        public static void UpdateCustomer(int id, string username, string email, string gender)
        {
            EditCustomerHandler.UpdateCustomer(id, username, email, gender);
            
        }

        public static List<string> GetDistinctGenders()
        {
            return EditCustomerHandler.GetDistinctGenders();
        }

        public static User GetUserById(int id)
        {
            return EditCustomerHandler.FindCustomerById(id);
        }

    }
}