﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Handler;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Controller
{
    public class EditRamenController
    {
        public static void UpdateRamen(int id, int meatId, string name, string broth, string price)
        {
            EditRamenHandler.UpdateRamen(id, meatId, name, broth, price);
        }

        public static Raman FindramenById(int id)
        {
            return EditRamenHandler.FindramenById(id);
        }

        public static List<Raman> GetAllRamen()
        {
            return EditRamenHandler.GetAllRamen();
        }

        public static List<string> GetDistinctBroth()
        {
            return EditRamenHandler.GetDistinctBroth();
        }

        public static List<string> GetDistinctMeatIds()
        {
            return EditRamenHandler.GetDistinctMeatIds();
        }

        public static void DeleteRamen(int id)
        {
            EditRamenHandler.DeleteRamen(id);
        }

    }
}