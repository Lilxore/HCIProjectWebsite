﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Repository
{
    public class EditRamenRepository
    {
        static Database1Entities db = new Database1Entities();

        public static Raman FindramenById(int id)
        {
            return db.Ramen.Find(id);
        }

        public static void UpdateRamen(Raman ramen)
        {

            db.SaveChanges();
        }

        public static List<Raman> GetAll()
        {
            return db.Ramen.ToList();
        }

        public static Meat GetMeatById(int id)
        {
            return db.Meats.FirstOrDefault(m => m.id == id);
        }

        public static List<string> GetDistinctBroth()
        {
            return db.Ramen.Select(x => x.Borth).Distinct().ToList();
        }

        public static List<string> GetDistinctMeatIds()
        {
            return db.Ramen.Select(x => x.Meatid.ToString()).Distinct().ToList();
        }

        public static void DeleteRamen(int id)
        {
            Raman ramen = FindramenById(id);
            if (ramen != null)
            {
                db.Ramen.Remove(ramen);
                db.SaveChanges();
            }
        }

    }
}