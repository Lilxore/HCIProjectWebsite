﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Repository
{
    public class EditCustomerRepository
    {
        static Database1Entities db = new Database1Entities();
        public static User FindCustomerById(int id)
        {
            return db.Users.Find(id);
        }

        public static void UpdateCustomer(User NewCustomer)
        {
            db.SaveChanges();
        }

        public static List<string> GetDistinctGenders()
        {
            return db.Users.Select(x => x.Gender).Distinct().ToList();
        }

    }
}