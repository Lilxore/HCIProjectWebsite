﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Repository
{
    public class TransactionRepository
    {
        static Database1Entities db = DatabaseSingleton.GetInstance();

        public static List<Header> GetHeaders()
        {
            return db.Headers.ToList();
        }

        public static Header GetTransactionById(int Id)
        {
            return (from x in db.Headers where x.id == Id select x).FirstOrDefault();
        }
    }
}