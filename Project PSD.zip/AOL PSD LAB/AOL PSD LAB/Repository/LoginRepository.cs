﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;
namespace AOL_PSD_LAB.Repository
{
    public class LoginRepository
    {
      private Database1Entities db;
     public LoginRepository()
      {
        db = new Database1Entities();
      }         
     public User GetUserByUsernameAndPassword(string username, string password)
       {
        return (from x in db.Users where x.Username.Equals(username) && x.Password.Equals(password) select x)
                .FirstOrDefault();

            }
        

    }
}