﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Factory
{
    public static class UserFactory
    {
        public static User CreateUser(string username, string email, string gender, string password, int roleId)
        {
            User newUser = new User
            {
                Username = username,
                Email = email,
                Gender = gender,
                Password = password,
                Roleid = roleId
            };

            return newUser;
        }
    }
}

