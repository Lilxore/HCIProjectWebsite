﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Factory
{
    public class InsertRamen
    {
        public static Raman create(int id, int Meatid, string Name, string Borth, string Price)
        {

            Raman r = new Raman();
            r.Name = Name;
            r.id = id;
            r.Meatid = Meatid;
            r.Borth = Borth;
            r.Price = Price;    
            
            return r;
        }



    }
}