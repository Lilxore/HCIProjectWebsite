﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Factory
{
    public class EditRamenFactory
    {
        public Raman CreateRamen(int id,int meat, string name ,string broth, string price)
        {
            Raman ramen = new Raman();
            ramen.id = id;
            ramen.Name = name;
            ramen.Price = price;
            ramen.Borth = broth;
            ramen.Meatid = meat;
            return ramen;
        }

    }
}