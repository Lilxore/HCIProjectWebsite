﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AOL_PSD_LAB.Models;

namespace AOL_PSD_LAB.Factory
{
    public class EditCustomerFactory
    {
      public User CreateNewCustomer(int id, string username, string email, string gender)
        {
            User NewCus = new User();
            NewCus.Id = id;
            NewCus.Username = username;
            NewCus.Email = email;
            NewCus.Gender = gender;

            return NewCus;
        }

    }
}